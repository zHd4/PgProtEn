﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PGPArticle.Contracts;
using PGPArticle.Services;

namespace PGPArticle.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            IEncryptionService encryptionService = new EncryptionService(@"C:\Program Files\GNU\GnuPG\pub\gpg2.exe");

            //  Change the parameters to your private key's keyuserid and input/output files.
            //var encryptedFile = encryptionService.EncryptFile("duke@lacrosse.com", @"C:\Users\dave\Desktop\LicAndPassport.PDF", @"F:\LicAndPassport.PDF.pgp");
            var encryptedFile = encryptionService.DecryptFile(@"F:\LicAndPassport.PDF.pgp", @"F:\LicAndPassport.pdf");

            Console.WriteLine(encryptedFile.Name);

            Console.ReadLine();

        }
    }
}
